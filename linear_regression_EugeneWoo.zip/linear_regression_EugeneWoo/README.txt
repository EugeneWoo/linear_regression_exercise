This project is adapted from Harvard University's statistical software workshop.

http://tutorials.iq.harvard.edu/R/Rstatistics/Rstatistics.html

These statistical software workshop materials by Harvard University are licensed 
under a Creative Commons Attribution-ShareAlike 4.0 International License.


